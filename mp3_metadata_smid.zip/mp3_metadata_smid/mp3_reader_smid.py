"""
Autor: Tomáš Šmíd
Předmět: Práce s daty - formát MP3
Popis:
  Tento program pomocí knihovny Mutagen načte metadata z MP3 souboru,
  vypíše je do konzole a jako bonus vytvoří kopii souboru s novými metadaty.
"""

from mutagen.mp3 import MP3
from mutagen.easyid3 import EasyID3
import os
import shutil


def read_mp3_metadata(file_path):
    """Načte a vypíše metadata z MP3 souboru."""
    if not os.path.exists(file_path):
        print(f"❌ Soubor '{file_path}' nebyl nalezen.")
        return

    try:
        audio = MP3(file_path, ID3=EasyID3)
    except Exception as e:
        print(f"❌ Chyba při načítání MP3: {e}")
        return

    print(f"\n🎵 Informace o souboru: {os.path.basename(file_path)}")
    print(f"📏 Délka skladby: {audio.info.length:.2f} sekund")
    print(f"📡 Bitrate: {audio.info.bitrate / 1000:.0f} kbps")

    print("\n🧾 Metadata:")
    if not audio:
        print("  (Soubor neobsahuje žádné ID3 tagy.)")
    else:
        for key, value in audio.items():
            print(f"  {key:10}: {', '.join(value)}")


def save_new_metadata(original_path, new_data):
    """Vytvoří kopii MP3 souboru a uloží do ní nová metadata."""
    # vytvoří kopii souboru, aby se originál nezměnil
    copy_path = original_path.replace(".mp3", "_upraveno.mp3")
    shutil.copy(original_path, copy_path)

    try:
        audio = MP3(copy_path, ID3=EasyID3)
    except Exception as e:
        print(f"❌ Chyba při načítání kopie MP3: {e}")
        return

    for key, value in new_data.items():
        audio[key] = value

    audio.save()
    print(f"\n💾 Nový soubor s upravenými metadaty vytvořen: {copy_path}")
    return copy_path


if __name__ == "__main__":
    # Soubor je ve stejné složce jako tento skript
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    mp3_file = os.path.join(BASE_DIR, "let_the_world_burn(hoodtrap_mylancore_remix).mp3")

    # 1️⃣ Načtení a výpis původních metadat
    read_mp3_metadata(mp3_file)

    # 2️⃣ Zeptá se uživatele, zda chce vytvořit upravenou kopii (bonus)
    choice = input("\nChceš vytvořit kopii s novými metadaty (bonus)? [a/n]: ").strip().lower()
    if choice == "a":
        new_tags = {
            "artist": ["Hoodtrap x Mylancore"],
            "title": ["Let The World Burn (Remix)"],
            "album": ["Python Demo Album"],
            "genre": ["Electronic"],
            "date": ["2025"],
        }

        new_file = save_new_metadata(mp3_file, new_tags)

        # 3️⃣ Znovu načti metadata z nové kopie
        if new_file:
            print("\n✅ Metadata v novém souboru:")
            read_mp3_metadata(new_file)
